# Streamlit introductory tutorial
 
 
## Basic commands to start streamlit

### Installation

`pip install streamlit`

### Run streamlit demo

`streamlit hello`

### Run your own streamlit app

`streamlit run {your app}.py`

### Get help on running streamlit

`streamlit --help`
